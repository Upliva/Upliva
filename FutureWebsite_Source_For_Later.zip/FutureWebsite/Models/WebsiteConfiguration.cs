using System.ComponentModel.DataAnnotations;

namespace UplivaAI.Models;

public class WebsiteConfiguration
{
    public int Id { get; set; }
    public int BusinessId { get; set; }

    [MaxLength(180)]
    public string WebsiteTitle { get; set; } = string.Empty;

    [MaxLength(300)]
    public string MetaDescription { get; set; } = string.Empty;

    [MaxLength(180)]
    public string HeroTitle { get; set; } = string.Empty;

    [MaxLength(500)]
    public string HeroSubtitle { get; set; } = string.Empty;

    [MaxLength(120)]
    public string AboutTitle { get; set; } = "About us";

    [MaxLength(3000)]
    public string AboutContent { get; set; } = string.Empty;

    [MaxLength(120)]
    public string WhyChooseUsTitle { get; set; } = "Why choose us";

    [MaxLength(3000)]
    public string WhyChooseUsContent { get; set; } = string.Empty;

    [MaxLength(120)]
    public string ServicesTitle { get; set; } = "Our services";

    [MaxLength(3000)]
    public string ServicesContent { get; set; } = string.Empty;

    [MaxLength(120)]
    public string CallToActionTitle { get; set; } = "Ready to connect?";

    [MaxLength(1000)]
    public string CallToActionText { get; set; } = string.Empty;

    [MaxLength(500)]
    public string ContactIntro { get; set; } = "Send us an enquiry and our team will get back to you.";

    [MaxLength(500)]
    public string FooterText { get; set; } = string.Empty;

    [MaxLength(40)]
    public string Theme { get; set; } = "Elegant";

    [MaxLength(20)]
    public string PrimaryColor { get; set; } = "#173b32";

    [MaxLength(20)]
    public string AccentColor { get; set; } = "#c7a26a";

    public bool ShowOffers { get; set; } = true;
    public bool ShowTestimonials { get; set; } = true;
    public bool ShowCatalog { get; set; } = true;
    public bool ShowWhatsApp { get; set; } = true;
    public bool ShowWhyChooseUs { get; set; } = true;
    public bool ShowServices { get; set; } = true;
    public bool ShowCallToAction { get; set; } = true;
}
